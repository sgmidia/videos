# Frontzapp SaaS - Plataforma de Automação WhatsApp

## Visão Geral

Frontzapp é uma plataforma SaaS para automação de WhatsApp, com recursos de campanhas, remarketing, webhooks e fluxos de conversação. A plataforma é construída com Next.js, Supabase e integração com n8n para processamento de automações.

## Tecnologias Utilizadas

- **Frontend**: Next.js 14 com App Router, React, Tailwind CSS, shadcn/ui
- **Backend**: Next.js API Routes, Supabase Functions
- **Banco de Dados**: PostgreSQL (via Supabase)
- **Autenticação**: Supabase Auth
- **Pagamentos**: Stripe
- **Automação**: n8n
- **Deploy**: Vercel

## Estrutura do Projeto

\`\`\`
frontzapp/
├── app/                  # Páginas e rotas da aplicação
│   ├── api/              # API routes
│   ├── auth/             # Páginas de autenticação
│   ├── dashboard/        # Dashboard principal
│   ├── whatsapp/         # Gerenciamento de conexões WhatsApp
│   ├── automacao/        # Webhooks, campanhas e remarketing
│   ├── fluxos/           # Fluxos de conversação
│   └── ...
├── components/           # Componentes React reutilizáveis
├── lib/                  # Bibliotecas e utilitários
│   ├── supabase/         # Cliente Supabase
│   ├── stripe.ts         # Integração com Stripe
│   └── n8n.ts            # Integração com n8n
├── types/                # Definições de tipos TypeScript
└── ...
\`\`\`

## Configuração do Ambiente

### Pré-requisitos

- Node.js 18+
- Conta Supabase
- Conta Stripe
- Instância n8n

### Variáveis de Ambiente

Crie um arquivo `.env.local` na raiz do projeto com as seguintes variáveis:

\`\`\`
# Supabase
NEXT_PUBLIC_SUPABASE_URL=sua-url-supabase
NEXT_PUBLIC_SUPABASE_ANON_KEY=sua-chave-anon-supabase
SUPABASE_SERVICE_ROLE_KEY=sua-chave-service-role

# Stripe
STRIPE_SECRET_KEY=sua-chave-secreta-stripe
STRIPE_WEBHOOK_SECRET=seu-webhook-secret-stripe
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=sua-chave-publicavel-stripe

# n8n
N8N_BASE_URL=sua-url-n8n
N8N_API_KEY=sua-api-key-n8n
N8N_WEBHOOK_SECRET=seu-webhook-secret-n8n
\`\`\`

### Configuração do Banco de Dados

1. Execute os scripts SQL para criar as tabelas necessárias no Supabase
2. Configure as políticas de segurança (RLS) para proteger os dados

### Configuração do Stripe

1. Crie produtos e preços no dashboard do Stripe
2. Configure o webhook do Stripe para apontar para `/api/webhook/stripe`
3. Adicione os IDs dos preços na tabela `plans`

### Configuração do n8n

1. Configure uma instância n8n (self-hosted ou cloud)
2. Crie uma API key para integração
3. Configure o webhook do n8n para apontar para `/api/webhook/n8n`

## Deploy

### Deploy na Vercel

1. Conecte seu repositório GitHub à Vercel
2. Configure as variáveis de ambiente na Vercel
3. Implante o projeto

### Configuração de Domínio Personalizado

1. Adicione seu domínio personalizado na Vercel
2. Configure os registros DNS conforme instruções da Vercel
3. Ative o SSL para seu domínio

## Escalabilidade

A arquitetura foi projetada para ser escalável:

- **Banco de Dados**: O Supabase escala automaticamente conforme a demanda
- **Serverless Functions**: As API routes do Next.js são executadas como funções serverless na Vercel
- **Isolamento de Dados**: Cada usuário tem seus dados isolados através de políticas RLS
- **n8n**: Cada usuário tem seu próprio usuário no n8n, garantindo isolamento de workflows

## Manutenção

### Backups

Configure backups automáticos do banco de dados Supabase para garantir a segurança dos dados.

### Monitoramento

Use o Vercel Analytics para monitorar o desempenho da aplicação e identificar problemas.

### Atualizações

Mantenha as dependências atualizadas regularmente para garantir segurança e performance.

## Suporte

Para suporte, entre em contato através do email suporte@frontzapp.com.br
\`\`\`

Agora, vamos criar a API para criar usuários no n8n:
